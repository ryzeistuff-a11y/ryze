# RyZe Hub — Native iOS source project

A standalone SwiftUI companion-interface prototype with:
- RyZe-branded dark UI
- Expand/minimize menu control
- Home, Tracker, and Settings tabs
- Demo token counter
- Chest-tracker toggle (UI demonstration only)
- Purple, red, and cyan accent themes

## Important limitations

This app is a standalone interface. It does **not** connect to Fortnite, inspect game memory, automate gameplay, locate live chests, or teleport a Fortnite character. iOS does not let an ordinary app float over another app like a system-wide overlay.

## Build requirements

- A Mac with a current version of Xcode
- An Apple ID for signing to a personal iPhone
- iOS 16.0 or later

## Open and build

1. Unzip the project on a Mac.
2. Open `RyZeHub.xcodeproj` in Xcode.
3. Select the `RyZeHub` target.
4. In **Signing & Capabilities**, choose your Apple development team.
5. Change the bundle identifier to a unique value you control, for example `com.yourname.ryzehub`.
6. Select your connected iPhone as the run destination.
7. Press **Run**.

To create an archive for distribution, select **Product → Archive** and follow Apple's signing/export workflow. KSign can sign a compatible IPA after an IPA has been built and exported; KSign does not compile Swift source code.

## Project structure

- `RyZeHub/App/RyZeHubApp.swift` — app entry point
- `RyZeHub/ContentView.swift` — complete SwiftUI interface
- `RyZeHub/Info.plist` — app configuration
