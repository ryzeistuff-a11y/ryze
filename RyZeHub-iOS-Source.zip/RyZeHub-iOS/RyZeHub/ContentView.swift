import SwiftUI

struct ContentView: View {
    @State private var menuExpanded = true
    @State private var chestTrackerEnabled = true
    @State private var tokenCount = 0
    @State private var selectedTab: HubTab = .home
    @State private var accent: HubAccent = .purple

    private var tint: Color { accent.color }

    var body: some View {
        ZStack {
            HubBackground(accent: tint)

            VStack(spacing: 0) {
                header

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        heroCard
                        if menuExpanded {
                            tabPicker
                            contentForSelectedTab
                        } else {
                            collapsedCard
                        }
                        footer
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 22)
                    .padding(.bottom, 30)
                }
            }

            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button {
                        withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) {
                            menuExpanded.toggle()
                        }
                    } label: {
                        HStack(spacing: 9) {
                            Image(systemName: menuExpanded ? "chevron.down" : "sparkles")
                                .font(.system(size: 14, weight: .bold))
                            Text(menuExpanded ? "MINIMIZE" : "OPEN RYZE")
                                .font(.system(size: 11, weight: .heavy, design: .rounded))
                                .tracking(1.2)
                        }
                        .foregroundStyle(.white)
                        .padding(.horizontal, 17)
                        .frame(height: 48)
                        .background(
                            LinearGradient(colors: [tint, tint.opacity(0.68)],
                                           startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .clipShape(Capsule())
                        .overlay(Capsule().stroke(.white.opacity(0.22), lineWidth: 1))
                        .shadow(color: tint.opacity(0.38), radius: 18, y: 7)
                    }
                    .buttonStyle(.plain)
                    .padding(.trailing, 20)
                    .padding(.bottom, 14)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 13)
                    .fill(LinearGradient(colors: [tint, tint.opacity(0.42)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 43, height: 43)
                Text("R")
                    .font(.system(size: 25, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("H")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.8))
                    .offset(x: 9, y: 8)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text("RYZE HUB")
                    .font(.system(size: 16, weight: .black, design: .rounded))
                    .tracking(2.1)
                    .foregroundStyle(.white)
                Text("FORTNITE COMPANION • DEMO")
                    .font(.system(size: 8, weight: .bold, design: .rounded))
                    .tracking(1.1)
                    .foregroundStyle(.white.opacity(0.48))
            }

            Spacer()

            HStack(spacing: 6) {
                Circle().fill(Color.green).frame(width: 6, height: 6)
                Text("READY")
                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                    .tracking(1)
            }
            .foregroundStyle(.white.opacity(0.8))
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(.white.opacity(0.06), in: Capsule())
            .overlay(Capsule().stroke(.white.opacity(0.08), lineWidth: 1))
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 16)
    }

    private var heroCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("CONTROL CENTER")
                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(tint.opacity(0.95))
                Spacer()
                Image(systemName: "waveform.path")
                    .foregroundStyle(tint)
            }

            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Your hub.\nYour setup.")
                        .font(.system(size: 29, weight: .black, design: .rounded))
                        .tracking(-0.8)
                        .foregroundStyle(.white)
                    Text("A customizable companion interface.")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.52))
                }
                Spacer()
                ZStack {
                    Circle().fill(tint.opacity(0.12)).frame(width: 76, height: 76)
                    Circle().stroke(tint.opacity(0.35), lineWidth: 1).frame(width: 62, height: 62)
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 26, weight: .black))
                        .foregroundStyle(tint)
                        .shadow(color: tint.opacity(0.8), radius: 12)
                }
            }
        }
        .padding(19)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 23))
        .overlay(RoundedRectangle(cornerRadius: 23).stroke(.white.opacity(0.09), lineWidth: 1))
    }

    private var tabPicker: some View {
        HStack(spacing: 7) {
            ForEach(HubTab.allCases) { tab in
                Button {
                    withAnimation(.easeInOut(duration: 0.18)) { selectedTab = tab }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: tab.symbol)
                        Text(tab.title)
                    }
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(selectedTab == tab ? .white : .white.opacity(0.48))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(selectedTab == tab ? tint.opacity(0.23) : .white.opacity(0.035),
                                in: RoundedRectangle(cornerRadius: 12))
                    .overlay(RoundedRectangle(cornerRadius: 12)
                        .stroke(selectedTab == tab ? tint.opacity(0.55) : .white.opacity(0.05), lineWidth: 1))
                }
                .buttonStyle(.plain)
            }
        }
    }

    @ViewBuilder
    private var contentForSelectedTab: some View {
        switch selectedTab {
        case .home:
            homeContent
        case .tracker:
            trackerContent
        case .settings:
            settingsContent
        }
    }

    private var homeContent: some View {
        VStack(spacing: 12) {
            HStack(spacing: 12) {
                MetricCard(title: "TOKENS", value: "\(tokenCount)", symbol: "sparkle",
                           tint: tint, subtitle: "Manual demo counter")
                MetricCard(title: "CHEST ROUTES", value: "0", symbol: "map",
                           tint: tint, subtitle: "No game connection")
            }

            HubPanel {
                VStack(alignment: .leading, spacing: 12) {
                    Label("QUICK ACTIONS", systemImage: "slider.horizontal.3")
                        .font(.system(size: 10, weight: .heavy, design: .rounded))
                        .tracking(1.4)
                        .foregroundStyle(.white.opacity(0.65))
                    HStack(spacing: 10) {
                        Button {
                            tokenCount += 1
                        } label: {
                            ActionTile(title: "ADD TOKEN", subtitle: "Demo counter",
                                       symbol: "plus.circle.fill", tint: tint)
                        }
                        .buttonStyle(.plain)
                        Button {
                            tokenCount = 0
                        } label: {
                            ActionTile(title: "RESET", subtitle: "Clear counter",
                                       symbol: "arrow.counterclockwise", tint: tint)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            noticeCard
        }
    }

    private var trackerContent: some View {
        VStack(spacing: 12) {
            HubPanel {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Label("CHEST TRACKER", systemImage: "shippingbox")
                            .font(.system(size: 11, weight: .heavy, design: .rounded))
                            .tracking(1)
                            .foregroundStyle(.white)
                        Spacer()
                        Toggle("", isOn: $chestTrackerEnabled)
                            .labelsHidden()
                            .tint(tint)
                            .scaleEffect(0.82, anchor: .trailing)
                    }
                    Text(chestTrackerEnabled
                         ? "Tracker demo is enabled. It does not scan Fortnite or locate live chests."
                         : "Tracker demo is paused.")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.52))
                    Divider().overlay(.white.opacity(0.08))
                    HStack {
                        Label("Saved locations", systemImage: "mappin.and.ellipse")
                        Spacer()
                        Text("0")
                            .font(.system(size: 13, weight: .black, design: .rounded))
                            .foregroundStyle(tint)
                    }
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.72))
                }
            }
            noticeCard
        }
    }

    private var settingsContent: some View {
        VStack(spacing: 12) {
            HubPanel {
                VStack(alignment: .leading, spacing: 14) {
                    Label("ACCENT COLOR", systemImage: "paintpalette")
                        .font(.system(size: 10, weight: .heavy, design: .rounded))
                        .tracking(1.3)
                        .foregroundStyle(.white.opacity(0.65))
                    HStack(spacing: 10) {
                        ForEach(HubAccent.allCases) { option in
                            Button {
                                withAnimation(.easeInOut(duration: 0.2)) { accent = option }
                            } label: {
                                VStack(spacing: 7) {
                                    Circle().fill(option.color).frame(width: 31, height: 31)
                                        .overlay(Circle().stroke(.white.opacity(accent == option ? 0.9 : 0.15),
                                                                 lineWidth: accent == option ? 2 : 1))
                                    Text(option.title)
                                        .font(.system(size: 9, weight: .bold))
                                        .foregroundStyle(.white.opacity(accent == option ? 0.95 : 0.45))
                                }
                                .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            HubPanel {
                VStack(alignment: .leading, spacing: 8) {
                    Label("ABOUT RYZE HUB", systemImage: "info.circle")
                        .font(.system(size: 10, weight: .heavy, design: .rounded))
                        .tracking(1.2)
                        .foregroundStyle(.white.opacity(0.65))
                    Text("Version 1.0 • Native SwiftUI prototype")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.55))
                }
            }
        }
    }

    private var noticeCard: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "info.circle.fill")
                .foregroundStyle(tint)
            Text("Standalone interface only. iOS apps cannot use this screen as an overlay on top of Fortnite, read its game memory, or teleport a live character.")
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(.white.opacity(0.56))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(tint.opacity(0.08), in: RoundedRectangle(cornerRadius: 15))
        .overlay(RoundedRectangle(cornerRadius: 15).stroke(tint.opacity(0.18), lineWidth: 1))
    }

    private var collapsedCard: some View {
        HubPanel {
            HStack(spacing: 12) {
                Image(systemName: "sparkles").foregroundStyle(tint)
                VStack(alignment: .leading, spacing: 3) {
                    Text("RYZE IS MINIMIZED")
                        .font(.system(size: 10, weight: .heavy, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(.white)
                    Text("Tap OPEN RYZE to expand the menu.")
                        .font(.system(size: 10))
                        .foregroundStyle(.white.opacity(0.5))
                }
                Spacer()
            }
        }
    }

    private var footer: some View {
        Text("RYZE HUB  •  INDEPENDENT COMMUNITY PROJECT")
            .font(.system(size: 8, weight: .bold, design: .rounded))
            .tracking(1.1)
            .foregroundStyle(.white.opacity(0.25))
            .padding(.top, 4)
    }
}

enum HubTab: String, CaseIterable, Identifiable {
    case home, tracker, settings
    var id: String { rawValue }
    var title: String {
        switch self {
        case .home: "HOME"
        case .tracker: "TRACKER"
        case .settings: "SETTINGS"
        }
    }
    var symbol: String {
        switch self {
        case .home: "house.fill"
        case .tracker: "scope"
        case .settings: "gearshape.fill"
        }
    }
}

enum HubAccent: String, CaseIterable, Identifiable {
    case purple, red, cyan
    var id: String { rawValue }
    var title: String { rawValue.uppercased() }
    var color: Color {
        switch self {
        case .purple: Color(red: 0.55, green: 0.30, blue: 1.0)
        case .red: Color(red: 1.0, green: 0.20, blue: 0.29)
        case .cyan: Color(red: 0.12, green: 0.78, blue: 1.0)
        }
    }
}

struct HubBackground: View {
    let accent: Color
    var body: some View {
        ZStack {
            Color(red: 0.035, green: 0.04, blue: 0.065)
            Circle().fill(accent.opacity(0.15)).frame(width: 280).blur(radius: 100)
                .offset(x: 150, y: -300)
            Circle().fill(Color.blue.opacity(0.07)).frame(width: 250).blur(radius: 90)
                .offset(x: -150, y: 300)
        }
        .ignoresSafeArea()
    }
}

struct HubPanel<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.075), lineWidth: 1))
    }
}

struct MetricCard: View {
    let title: String
    let value: String
    let symbol: String
    let tint: Color
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Image(systemName: symbol).font(.system(size: 14, weight: .bold)).foregroundStyle(tint)
            Text(value).font(.system(size: 27, weight: .black, design: .rounded)).foregroundStyle(.white)
            Text(title).font(.system(size: 9, weight: .heavy, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.72))
            Text(subtitle).font(.system(size: 8, weight: .medium)).foregroundStyle(.white.opacity(0.35))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(15)
        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 17))
        .overlay(RoundedRectangle(cornerRadius: 17).stroke(.white.opacity(0.075), lineWidth: 1))
    }
}

struct ActionTile: View {
    let title: String
    let subtitle: String
    let symbol: String
    let tint: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: symbol).font(.system(size: 18, weight: .bold)).foregroundStyle(tint)
            Text(title).font(.system(size: 9, weight: .heavy, design: .rounded)).tracking(0.6).foregroundStyle(.white)
            Text(subtitle).font(.system(size: 8, weight: .medium)).foregroundStyle(.white.opacity(0.4))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(tint.opacity(0.09), in: RoundedRectangle(cornerRadius: 13))
        .overlay(RoundedRectangle(cornerRadius: 13).stroke(tint.opacity(0.18), lineWidth: 1))
    }
}
